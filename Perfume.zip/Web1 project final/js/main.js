

function All() {
  document.getElementById('AllProdect').innerHTML = `
  
  <!--post box 1-->
        <div class="post-box Women">
            <img src="img/womim1.png" alt="" class="post-img">
            <h2 class="category">Women</h2>
            <a href="post-page.html" class="post-title">
                Yves Saint Laurent  
            </a>
            <span class="post-name"> EGP 2822</span>
            <p class="post-discription">Eau de Parfum Libre for Women by Yves Saint Laurent - 50 ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/womim1.png" alt="" class="profile-img">
                <span class="profile-name">women perfumes</span>
            </div>
        </div>




        <!--post box 2-->
        <div class="post-box Men">
            <img src="img/menim2.png" alt="" class="post-img">
            <h2 class="category">Men</h2>
            <a href="post-page.html" class="post-title">
                Bvlgari   
            </a>
            <span class="post-name">EGP 2824</span>
            <p class="post-discription">Man Terrae Essence by Bvlgari for Men - EDP - 100ml
                Bvlgari</p>
            <!--profile-->
            <div class="profile">
                <img src="img/menim2.png" alt="" class="profile-img">
                <span class="profile-name">men perfumes</span>
            </div>
        </div>

         <!--post box 3-->
         <div class="post-box Children">
            <img src="img/chilim3.png" alt="" class="post-img">
            <h2 class="category">Children</h2>
            <a href="post-page.html" class="post-title">
                TOCCA   
            </a>
            <span class="post-name">EGP 1110 </span>
            <p class="post-discription">Hair Fragrance</p>
            <!--profile-->
            <div class="profile">
                <img src="img/chilim3.png" alt="" class="profile-img">
                <span class="profile-name">children perfumes</span>
            </div>
        </div>

        <!--post box 4-->
        <div class="post-box Women">
            <img src="img/women1.png" alt="" class="post-img">
            <h2 class="category">Women</h2>
            <a href="post-page.html" class="post-title">
                TOM FORD  
            </a>
            <span class="post-name">EGP 3500</span>
            <p class="post-discription">SOLEIL BLANC Shimmering body oil</p>
            <!--profile-->
            <div class="profile">
                <img src="img/womim1.png" alt="" class="profile-img">
                <span class="profile-name">women perfumes</span>
            </div>
        </div>

        <!--post box 5-->
        <div class="post-box Men">
            <img src="img/men1.png" alt="" class="post-img">
            <h2 class="category">Men</h2>
            <a href="post-page.html" class="post-title">
                BLEU DE CHANEL 
            </a>
            <span class="post-name">EGP 7000</span>
            <p class="post-discription">Bleu De Chanel Paris EDP Pour Homme Vaporisateur Spray For Men 100ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/menim2.png" alt="" class="profile-img">
                <span class="profile-name">men perfumes</span>
            </div>
        </div>

         <!--post box 6-->
         <div class="post-box Children">
            <img src="img/cheldrin1.png" alt="" class="post-img">
            <h2 class="category">Children</h2>
            <a href="post-page.html" class="post-title">
                Le Jolie  
            </a>
            <span class="post-name">EGP 500</span>
            <p class="post-discription">Baby Jolie Le Jolie Memory Perfume for Babies 50ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/chilim3.png" alt="" class="profile-img">
                <span class="profile-name">children perfumes</span>
            </div>
        </div>

        <!--post box 7-->
        <div class="post-box Women">
            <img src="img/women2.png" alt="" class="post-img">
            <h2 class="category">Women</h2>
            <a href="post-page.html" class="post-title">
                Victorias Secret  
            </a>
            <span class="post-name">EGP 3980</span>
            <p class="post-discription">Angel Gold EDP 100ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/womim1.png" alt="" class="profile-img">
                <span class="profile-name">women perfumes</span>
            </div>
        </div>

        <!--post box 8-->
        <div class="post-box Men">
            <img src="img/men2.png" alt="" class="post-img">
            <h2 class="category">Men</h2>
            <a href="post-page.html" class="post-title">
                Tom Ford  
            </a>
            <span class="post-name">EGP 6800</span>
            <p class="post-discription">Ombré Leather Parfum Tom Ford for women and men 100ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/menim2.png" alt="" class="profile-img">
                <span class="profile-name">men perfumes</span>
            </div>
        </div>

         <!--post box 9-->
         <div class="post-box Children">
            <img src="img/cheldrin2.png" alt="" class="post-img">
            <h2 class="category">Children</h2>
            <a href="post-page.html" class="post-title">
                DUMBO  
            </a>
            <span class="post-name">EGP 500</span>
            <p class="post-discription">Mini Special DELIVERY 50ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/chilim3.png" alt="" class="profile-img">
                <span class="profile-name">children perfumes</span>
            </div>
        </div>

        <!--post box 10-->
        <div class="post-box Women">
            <img src="img/women3.png" alt="" class="post-img">
            <h2 class="category">Women</h2>
            <a href="post-page.html" class="post-title">
                Dior
            </a>
            <span class="post-name">EGP 3346</span>
            <p class="post-discription">Dior Joy by Christian Dior Eau De Parfum Spray</p>
            <!--profile-->
            <div class="profile">
                <img src="img/womim1.png" alt="" class="profile-img">
                <span class="profile-name">women perfumes</span>
            </div>
        </div>

        <!--post box 11-->
        <div class="post-box Men">
            <img src="img/men3.png" alt="" class="post-img">
            <h2 class="category">Men</h2>
            <a href="post-page.html" class="post-title">
                BLEU DE CHANEL  
            </a>
            <span class="post-name">EGP 7000</span>
            <p class="post-discription">Bleu De Chanel Paris EDP Pour Homme Vaporisateur Spray For Men 100ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/menim2.png" alt="" class="profile-img">
                <span class="profile-name">men perfumes</span>
            </div>
        </div>

         <!--post box 12-->
         <div class="post-box Children">
            <img src="img/cheldrin3.png" alt="" class="post-img">
            <h2 class="category">Children</h2>
            <a href="post-page.html" class="post-title">
                Maui  
            </a>
            <span class="post-name">EGP 300</span>
            <p class="post-discription">Fantasy Britney Spears Eau</p>
            <!--profile-->
            <div class="profile">
                <img src="img/chilim3.png" alt="" class="profile-img">
                <span class="profile-name">children perfumes</span>
            </div>
        </div>

        <!--post box 13-->
        <div class="post-box Women">
            <img src="img/women4.png" alt="" class="post-img">
            <h2 class="category">Women</h2>
            <a href="post-page.html" class="post-title">
                Daisy
            </a>
            <span class="post-name">EGP 3837</span>
            <p class="post-discription"> Eau De Toilette Spray Marc Jacobs</p>
            <!--profile-->
            <div class="profile">
                <img src="img/womim1.png" alt="" class="profile-img">
                <span class="profile-name">women perfumes</span>
            </div>
        </div>

        <!--post box 14-->
        <div class="post-box Men">
            <img src="img/men4.png" alt="" class="post-img">
            <h2 class="category">Men</h2>
            <a href="post-page.html" class="post-title">
                Boss Bottled  
            </a>
            <span class="post-name">EGP 2000</span>
            <p class="post-discription">Boss Bottled by Hugo Boss is a Woody Spicy fragrance for men. Boss Bottled was launched in 1998. 100ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/menim2.png" alt="" class="profile-img">
                <span class="profile-name">men perfumes</span>
            </div>
        </div>


         <!--post box 15-->
         <div class="post-box Children">
            <img src="img/cheldrin4.png" alt="" class="post-img">
            <h2 class="category">Children</h2>
            <a href="post-page.html" class="post-title">
                Disney  
            </a>
            <span class="post-name">EGP 350</span>
            <p class="post-discription">Oriflame Disney Fairies Perfume 100ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/chilim3.png" alt="" class="profile-img">
                <span class="profile-name">children perfumes</span>
            </div>
        </div>

            <!--post box 16-->
            <div class="post-box">
            <img src="img/women5.png" alt="" class="post-img">
            <h2 class="category">Women</h2>
            <a href="post-page.html" class="post-title">
                Dior  
            </a>
            <span class="post-name">EGP 5000</span>
            <p class="post-discription">Miss Dior Eau de Parfum reinvents itself with a new scent.</p>
            <!--profile-->
            <div class="profile">
                <img src="img/womim1.png" alt="" class="profile-img">
                <span class="profile-name">women perfumes</span>
            </div>
        </div>


        <!--post box 17-->
        <div class="post-box Men">
            <img src="img/men5.png" alt="" class="post-img">
            <h2 class="category">Men</h2>
            <a href="post-page.html" class="post-title">
                Bvlgari Man  
            </a>
            <span class="post-name">EGP 2800</span>
            <p class="post-discription">Terrae Essence by Bvlgari for Men - EDP - 100ml
                Bvlgari</p>
            <!--profile-->
            <div class="profile">
                <img src="img/menim2.png" alt="" class="profile-img">
                <span class="profile-name">men perfumes</span>
            </div>
        </div>


         <!--post box 18-->
         <div class="post-box Children">
            <img src="img/cheldrin5.png" alt="" class="post-img">
            <h2 class="category">Children</h2>
            <a href="post-page.html" class="post-title">
                Don Algodon  
            </a>
            <span class="post-name">EGP 550</span>
            <p class="post-discription">Children's Perfume Don Cotton Baby 100ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/chilim3.png" alt="" class="profile-img">
                <span class="profile-name">children perfumes</span>
            </div>
        </div>


        <!--post box 19-->
        <div class="post-box Women">
            <img src="img/women6.png" alt="" class="post-img">
            <h2 class="category">Women</h2>
            <a href="post-page.html" class="post-title">
                Vera Wang  
            </a>
            <span class="post-name">EGP 2100</span>
            <p class="post-discription">Princess Vera Wang Eau De Toilette Spray</p>
            <!--profile-->
            <div class="profile">
                <img src="img/womim1.png" alt="" class="profile-img">
                <span class="profile-name">women perfumes</span>
            </div>
        </div>


        <!--post box 20-->
        <div class="post-box Men">
            <img src="img/men6.png" alt="" class="post-img">
            <h2 class="category">Men</h2>
            <a href="post-page.html" class="post-title">
                Dior  
            </a>
            <span class="post-name">EGP 5000</span>
            <p class="post-discription">The refreshing, sharp men’s fragrance Dior Sauvage is specially designed for sincere men who are honest with themselves and their surroundings. 60ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/menim2.png" alt="" class="profile-img">
                <span class="profile-name">men perfumes</span>
            </div>
        </div>


         <!--post box 21-->
         <div class="post-box Children">
            <img src="img/cheldrin6.png" alt="" class="post-img">
            <h2 class="category">Children</h2>
            <a href="post-page.html" class="post-title">
                Baby Tous  
            </a>
            <span class="post-name">EGP 500</span>
            <p class="post-discription">Baby Tous by Tous Eau De Cologne Spray 70ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/chilim3.png" alt="" class="profile-img">
                <span class="profile-name">children perfumes</span>
            </div>
        </div>

        
        <!--post box 22-->
        <div class="post-box Women">
            <img src="img/women7.png" alt="" class="post-img">
            <h2 class="category">Women</h2>
            <a href="post-page.html" class="post-title">
                Lollia  
            </a>
            <span class="post-name">EGP 3000</span>
            <p class="post-discription">Lollia  Always in Rose Eau de Parfum  with Dusting Powder & Little Luxuries 100ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/womim1.png" alt="" class="profile-img">
                <span class="profile-name">women perfumes</span>
            </div>
        </div>


        <!--post box 23-->
        <div class="post-box Men">
            <img src="img/men7.png" alt="" class="post-img">
            <h2 class="category">Men</h2>
            <a href="post-page.html" class="post-title">
                Kamila Aubre  
            </a>
            <span class="post-name">EGP 3000</span>
            <p class="post-discription">Arabic perfume for men 100ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/menim2.png" alt="" class="profile-img">
                <span class="profile-name">men perfumes</span>
            </div>
        </div>


         <!--post box 24-->
         <div class="post-box Children">
            <img src="img/cheldrin7.png" alt="" class="post-img">
            <h2 class="category">Children</h2>
            <a href="post-page.html" class="post-title">
                Miss Nella  
            </a>
            <span class="post-name">EGP 150</span>
            <p class="post-discription">Miss Nella cool like me gift 10ml</p>


            <!--profile-->
            <div class="profile">
                <img src="img/chilim3.png" alt="" class="profile-img">
                <span class="profile-name">children perfumes</span>
            </div>
        </div>

  `
}


function Women() {
  document.getElementById('AllProdect').innerHTML = `
  <!--post box 1-->
        <div class="post-box Women">
            <img src="img/womim1.png" alt="" class="post-img">
            <h2 class="category">Women</h2>
            <a href="post-page.html" class="post-title">
                Yves Saint Laurent  
            </a>
            <span class="post-name"> EGP 2822</span>
            <p class="post-discription">Eau de Parfum Libre for Women by Yves Saint Laurent - 50 ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/womim1.png" alt="" class="profile-img">
                <span class="profile-name">women perfumes</span>
            </div>
        </div>


        <div class="post-box Women">
            <img src="img/women1.png" alt="" class="post-img">
            <h2 class="category">Women</h2>
            <a href="post-page.html" class="post-title">
                TOM FORD  
            </a>
            <span class="post-name">EGP 3500</span>
            <p class="post-discription">SOLEIL BLANC Shimmering body oil</p>
            <!--profile-->
            <div class="profile">
                <img src="img/womim1.png" alt="" class="profile-img">
                <span class="profile-name">women perfumes</span>
            </div>
        </div>
  
        <!--post box 7-->
        <div class="post-box Women">
            <img src="img/women2.png" alt="" class="post-img">
            <h2 class="category">Women</h2>
            <a href="post-page.html" class="post-title">
                Victorias Secret  
            </a>
            <span class="post-name">EGP 3980</span>
            <p class="post-discription">Angel Gold EDP 100ml</p>
            <!--profile-->
            <div class="profile">
                <img src="img/womim1.png" alt="" class="profile-img">
                <span class="profile-name">women perfumes</span>
            </div>
        </div>

        <!--post box 10-->
        <div class="post-box Women">
            <img src="img/women3.png" alt="" class="post-img">
            <h2 class="category">Women</h2>
            <a href="post-page.html" class="post-title">
                Dior
            </a>
            <span class="post-name">EGP 3346</span>
            <p class="post-discription">Dior Joy by Christian Dior Eau De Parfum Spray</p>
            <!--profile-->
            <div class="profile">
                <img src="img/womim1.png" alt="" class="profile-img">
                <span class="profile-name">women perfumes</span>
            </div>
        </div>


        <!--post box 13-->
        <div class="post-box Women">
            <img src="img/women4.png" alt="" class="post-img">
            <h2 class="category">Women</h2>
            <a href="post-page.html" class="post-title">
                Daisy
            </a>
            <span class="post-name">EGP 3837</span>
            <p class="post-discription"> Eau De Toilette Spray Marc Jacobs</p>
            <!--profile-->
            <div class="profile">
                <img src="img/womim1.png" alt="" class="profile-img">
                <span class="profile-name">women perfumes</span>
            </div>
        </div>



        <!--post box 19-->
        <div class="post-box Women">
            <img src="img/women6.png" alt="" class="post-img">
            <h2 class="category">Women</h2>
            <a href="post-page.html" class="post-title">
                Vera Wang  
            </a>
            <span class="post-name">EGP 2100</span>
            <p class="post-discription">Princess Vera Wang Eau De Toilette Spray</p>
            <!--profile-->
            <div class="profile">
                <img src="img/womim1.png" alt="" class="profile-img">
                <span class="profile-name">women perfumes</span>
            </div>
        </div>


        <div class="post-box Women">
        <img src="img/women7.png" alt="" class="post-img">
        <h2 class="category">Women</h2>
        <a href="post-page.html" class="post-title">
            Lollia  
        </a>
        <span class="post-name">EGP 3000</span>
        <p class="post-discription">Lollia  Always in Rose Eau de Parfum  with Dusting Powder & Little Luxuries 100ml</p>
        <!--profile-->
        <div class="profile">
            <img src="img/womim1.png" alt="" class="profile-img">
            <span class="profile-name">women perfumes</span>
        </div>
    </div>








  
  `
}



function Men() {
  document.getElementById('AllProdect').innerHTML = `
  
  <div class="post-box Men">
    <img src="img/menim2.png" alt="" class="post-img">
    <h2 class="category">Men</h2>
    <a href="post-page.html" class="post-title">
        Bvlgari   
    </a>
    <span class="post-name">EGP 2824</span>
    <p class="post-discription">Man Terrae Essence by Bvlgari for Men - EDP - 100ml
        Bvlgari</p>
    <!--profile-->
    <div class="profile">
        <img src="img/menim2.png" alt="" class="profile-img">
        <span class="profile-name">men perfumes</span>
    </div>
</div>
  
  
<!--post box 5-->
<div class="post-box Men">
    <img src="img/men1.png" alt="" class="post-img">
    <h2 class="category">Men</h2>
    <a href="post-page.html" class="post-title">
        BLEU DE CHANEL 
    </a>
    <span class="post-name">EGP 7000</span>
    <p class="post-discription">Bleu De Chanel Paris EDP Pour Homme Vaporisateur Spray For Men 100ml</p>
    <!--profile-->
    <div class="profile">
        <img src="img/menim2.png" alt="" class="profile-img">
        <span class="profile-name">men perfumes</span>
    </div>
</div>



<!--post box 8-->
<div class="post-box Men">
    <img src="img/men2.png" alt="" class="post-img">
    <h2 class="category">Men</h2>
    <a href="post-page.html" class="post-title">
        Tom Ford  
    </a>
    <span class="post-name">EGP 6800</span>
    <p class="post-discription">Ombré Leather Parfum Tom Ford for women and men 100ml</p>
    <!--profile-->
    <div class="profile">
        <img src="img/menim2.png" alt="" class="profile-img">
        <span class="profile-name">men perfumes</span>
    </div>
</div>

<!--post box 11-->
<div class="post-box Men">
    <img src="img/men3.png" alt="" class="post-img">
    <h2 class="category">Men</h2>
    <a href="post-page.html" class="post-title">
        BLEU DE CHANEL  
    </a>
    <span class="post-name">EGP 7000</span>
    <p class="post-discription">Bleu De Chanel Paris EDP Pour Homme Vaporisateur Spray For Men 100ml</p>
    <!--profile-->
    <div class="profile">
        <img src="img/menim2.png" alt="" class="profile-img">
        <span class="profile-name">men perfumes</span>
    </div>
</div>


<!--post box 14-->
<div class="post-box Men">
    <img src="img/men4.png" alt="" class="post-img">
    <h2 class="category">Men</h2>
    <a href="post-page.html" class="post-title">
        Boss Bottled  
    </a>
    <span class="post-name">EGP 2000</span>
    <p class="post-discription">Boss Bottled by Hugo Boss is a Woody Spicy fragrance for men. Boss Bottled was launched in 1998. 100ml</p>
    <!--profile-->
    <div class="profile">
        <img src="img/menim2.png" alt="" class="profile-img">
        <span class="profile-name">men perfumes</span>
    </div>
</div>


<!--post box 17-->
<div class="post-box Men">
    <img src="img/men5.png" alt="" class="post-img">
    <h2 class="category">Men</h2>
    <a href="post-page.html" class="post-title">
        Bvlgari Man  
    </a>
    <span class="post-name">EGP 2800</span>
    <p class="post-discription">Terrae Essence by Bvlgari for Men - EDP - 100ml
        Bvlgari</p>
    <!--profile-->
    <div class="profile">
        <img src="img/menim2.png" alt="" class="profile-img">
        <span class="profile-name">men perfumes</span>
    </div>
</div>


<!--post box 20-->
<div class="post-box Men">
    <img src="img/men6.png" alt="" class="post-img">
    <h2 class="category">Men</h2>
    <a href="post-page.html" class="post-title">
        Dior  
    </a>
    <span class="post-name">EGP 5000</span>
    <p class="post-discription">The refreshing, sharp men’s fragrance Dior Sauvage is specially designed for sincere men who are honest with themselves and their surroundings. 60ml</p>
    <!--profile-->
    <div class="profile">
        <img src="img/menim2.png" alt="" class="profile-img">
        <span class="profile-name">men perfumes</span>
    </div>
</div>


<!--post box 23-->
<div class="post-box Men">
    <img src="img/men7.png" alt="" class="post-img">
    <h2 class="category">Men</h2>
    <a href="post-page.html" class="post-title">
        Kamila Aubre  
    </a>
    <span class="post-name">EGP 3000</span>
    <p class="post-discription">Arabic perfume for men 100ml</p>
    <!--profile-->
    <div class="profile">
        <img src="img/menim2.png" alt="" class="profile-img">
        <span class="profile-name">men perfumes</span>
    </div>
</div>





  
  `
}





function Children() {

  document.getElementById('AllProdect').innerHTML = `
  
  <!--post box 3-->
  <div class="post-box Children">
     <img src="img/chilim3.png" alt="" class="post-img">
     <h2 class="category">Children</h2>
     <a href="post-page.html" class="post-title">
         TOCCA   
     </a>
     <span class="post-name">EGP 1110 </span>
     <p class="post-discription">Hair Fragrance</p>
     <!--profile-->
     <div class="profile">
         <img src="img/chilim3.png" alt="" class="profile-img">
         <span class="profile-name">children perfumes</span>
     </div>
 </div>

   <!--post box 6-->
 <div class="post-box Children">
    <img src="img/cheldrin1.png" alt="" class="post-img">
    <h2 class="category">Children</h2>
    <a href="post-page.html" class="post-title">
        Le Jolie  
    </a>
    <span class="post-name">EGP 500</span>
    <p class="post-discription">Baby Jolie Le Jolie Memory Perfume for Babies 50ml</p>
    <!--profile-->
    <div class="profile">
        <img src="img/chilim3.png" alt="" class="profile-img">
        <span class="profile-name">children perfumes</span>
    </div>
</div>
  
<!--post box 9-->
<div class="post-box Children">
   <img src="img/cheldrin2.png" alt="" class="post-img">
   <h2 class="category">Children</h2>
   <a href="post-page.html" class="post-title">
       DUMBO  
   </a>
   <span class="post-name">EGP 500</span>
   <p class="post-discription">Mini Special DELIVERY 50ml</p>
   <!--profile-->
   <div class="profile">
       <img src="img/chilim3.png" alt="" class="profile-img">
       <span class="profile-name">children perfumes</span>
   </div>
</div>
  
<!--post box 12-->
<div class="post-box Children">
   <img src="img/cheldrin3.png" alt="" class="post-img">
   <h2 class="category">Children</h2>
   <a href="post-page.html" class="post-title">
       Maui  
   </a>
   <span class="post-name">EGP 300</span>
   <p class="post-discription">Fantasy Britney Spears Eau</p>
   <!--profile-->
   <div class="profile">
       <img src="img/chilim3.png" alt="" class="profile-img">
       <span class="profile-name">children perfumes</span>
   </div>
</div>
  
<!--post box 15-->
<div class="post-box Children">
   <img src="img/cheldrin4.png" alt="" class="post-img">
   <h2 class="category">Children</h2>
   <a href="post-page.html" class="post-title">
       Disney  
   </a>
   <span class="post-name">EGP 350</span>
   <p class="post-discription">Oriflame Disney Fairies Perfume 100ml</p>
   <!--profile-->
   <div class="profile">
       <img src="img/chilim3.png" alt="" class="profile-img">
       <span class="profile-name">children perfumes</span>
   </div>
</div>
  
<!--post box 18-->
<div class="post-box Children">
   <img src="img/cheldrin5.png" alt="" class="post-img">
   <h2 class="category">Children</h2>
   <a href="post-page.html" class="post-title">
       Don Algodon  
   </a>
   <span class="post-name">EGP 550</span>
   <p class="post-discription">Children's Perfume Don Cotton Baby 100ml</p>
   <!--profile-->
   <div class="profile">
       <img src="img/chilim3.png" alt="" class="profile-img">
       <span class="profile-name">children perfumes</span>
   </div>
</div>
  
<!--post box 21-->
<div class="post-box Children">
   <img src="img/cheldrin6.png" alt="" class="post-img">
   <h2 class="category">Children</h2>
   <a href="post-page.html" class="post-title">
       Baby Tous  
   </a>
   <span class="post-name">EGP 500</span>
   <p class="post-discription">Baby Tous by Tous Eau De Cologne Spray 70ml</p>
   <!--profile-->
   <div class="profile">
       <img src="img/chilim3.png" alt="" class="profile-img">
       <span class="profile-name">children perfumes</span>
   </div>
</div>
  
<!--post box 24-->
<div class="post-box Children">
   <img src="img/cheldrin7.png" alt="" class="post-img">
   <h2 class="category">Children</h2>
   <a href="post-page.html" class="post-title">
       Miss Nella  
   </a>
   <span class="post-name">EGP 150</span>
   <p class="post-discription">Miss Nella cool like me gift 10ml</p>

   <!--profile-->
   <div class="profile">
       <img src="img/chilim3.png" alt="" class="profile-img">
       <span class="profile-name">children perfumes</span>
   </div>
</div>

  `
}

// JQ //


$(".navHeder").slideDown(2000,function () {
    $(".content").fadeIn(2000,function () {
        $(".buttons").slideDown(2000,function(){
            $(".foterend").slideDown(2000)
        })
      })
  });



